package com.cts;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.cts.model.Book;
import com.cts.repository.BookRepository;
import com.cts.repository.BorrowRepository;
import com.cts.services.BookService;
import com.cts.services.BorrowService;
import com.cts.services.UserService;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;

@SpringBootTest
class BookNestApplicationTests {

    @Mock
    private BookRepository bookRepository;

    @InjectMocks
    private BookService bookService;

    @Mock
    private BorrowRepository borrowRepository;

    @Mock
    private UserService userService;

    @InjectMocks
    private BorrowService borrowService;


    @Test
    public void testGetAllBooks() {
        Book book1 = new Book();
        book1.setId(1L);
        book1.setBookTitle("Book 1");

        Book book2 = new Book();
        book2.setId(2L);
        book2.setBookTitle("Book 2");

        List<Book> books = Arrays.asList(book1, book2);

        when(bookRepository.findAll()).thenReturn(books);

        List<Book> result = bookService.getAllBooks();
        assertEquals(2, result.size());
        verify(bookRepository, times(1)).findAll();
    }

    @Test
    public void testGetBookById() {
        Book book = new Book();
        book.setId(1L);
        book.setBookTitle("Book 1");

        when(bookRepository.findById(1L)).thenReturn(Optional.of(book));

        Book result = bookService.getBookById(1L);
        assertEquals("Book 1", result.getBookTitle());
        verify(bookRepository, times(1)).findById(1L);
    }

    @Test
    public void testAddBook() {
        Book book = new Book();
        book.setId(1L);
        book.setBookTitle("Book 1");

        when(bookRepository.save(book)).thenReturn(book);

        Book result = bookService.addBook(book);
        assertEquals("Book 1", result.getBookTitle());
        verify(bookRepository, times(1)).save(book);
    }
 }