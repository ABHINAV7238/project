package com.cts.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.model.BookRequest;

public interface BookRequestRepository extends JpaRepository<BookRequest, Long> {

}
