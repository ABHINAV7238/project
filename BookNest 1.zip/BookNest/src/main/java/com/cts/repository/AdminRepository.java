package com.cts.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long>{
	Admin findByEmail(String email);
}
