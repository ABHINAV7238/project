package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.model.Borrow;
import com.cts.model.BorrowStatus;

public interface BorrowRepository extends JpaRepository<Borrow, Long> {
	List<Borrow> findByUserId(Long userID);
    List<Borrow> findByBookId(Long bookId);
    List<Borrow> findByUserIdAndStatusIn(Long userId, List<BorrowStatus> status);
	    
}
