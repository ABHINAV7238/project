package com.cts.exception;

public class BorrowNotFoundException extends RuntimeException{
	public BorrowNotFoundException(long id){
        super("Borrow Id "+ id +" not found");
    }

}
