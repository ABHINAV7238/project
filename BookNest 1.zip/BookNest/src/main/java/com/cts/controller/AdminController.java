package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cts.model.Admin;
import com.cts.model.LoginRequest;
import com.cts.services.AdminService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api")
public class AdminController {
    @Autowired
    private AdminService adminService;

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    // Gets a list of all admins
    @GetMapping("/admin")
    public List<Admin> getAllAdmin() {
        logger.info("Fetching all admins");
        return adminService.getAllAdmin();
    }
    
    // Adding a new admin
    @PostMapping("/admin")
    public Admin addAdmin(@RequestBody Admin admin) {
        logger.info("Adding new admin: {}", admin.getEmail());
        return adminService.addAdmin(admin);
    }
    
    // Get an admin by ID
    @GetMapping("/admin/{id}")
    public Admin getAdminById(@PathVariable long id){
        logger.info("Fetching admin with ID: {}", id);
        return adminService.findById(id);
    }
    
    // Delete an admin by ID
    @DeleteMapping("/admin/{id}")
    public void deleteAdmin(@PathVariable long id) {
        logger.info("Deleting admin with ID: {}", id);
        adminService.deleteAdmin(id);
    }
    
    // Update an admin by ID
    @PutMapping("/admin/{id}")
    public Admin updateAdmin(@RequestBody Admin admin, @PathVariable long id){
        logger.info("Updating admin with ID: {}", id);
        Admin updateAdmin = adminService.findById(id);

        updateAdmin.setName(admin.getName());
        updateAdmin.setEmail(admin.getEmail());   
        updateAdmin.setPhoneNumber(admin.getPhoneNumber());
        updateAdmin.setPassword(admin.getPassword());
        Admin updatedAdmin = adminService.updateAdmin(updateAdmin);
        logger.info("Updated admin: {}", updatedAdmin.getEmail());
        return updatedAdmin;    // Return the updated admin
    }

    // Admin login
    @PostMapping("/adminLogin")
    public @ResponseBody Admin login(@RequestBody LoginRequest loginRequest) {  // loginRequest the login request containing email and password
        logger.info("Admin login attempt: {}", loginRequest.getEmail());
        Admin admin = adminService.login(loginRequest);
        if (admin != null) {
            logger.info("Admin login successful: {}", admin.getEmail());
        } else {
            logger.info("Admin login failed for email: {}", loginRequest.getEmail());
        }
        return admin;      // Return the logged-in admin
    }
}
