package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cts.model.Borrow;
import com.cts.repository.BorrowRepository;
import com.cts.services.BookService;
import com.cts.services.BorrowService;
import com.cts.services.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api")
public class BorrowBookController {
    @Autowired
    private BorrowService borrowService;
    @Autowired
    private UserService userService;
    @Autowired
    private BookService bookService;
    @Autowired
    private BorrowRepository borrowRepository;

    private static final Logger logger = LoggerFactory.getLogger(BorrowBookController.class);

    // Get all borrow records
    @GetMapping("/borrow")
    public List<Borrow> getAllBorrows() {
        logger.info("Fetching all borrow records");
        return borrowService.findAll();
    }

    // Get a borrow record by ID
    @GetMapping("/borrow/{id}")
    public Borrow getRequestsByID(@PathVariable long id) {
        logger.info("Fetching borrow record with ID: {}", id);
        return borrowService.findById(id);
    }

    // Get all borrow records for a specific user by user ID
    @GetMapping("/borrow/user/{userID}")
    public List<Borrow> getBorrowedBooks(@PathVariable long userID) {
        logger.info("Fetching borrow records for user ID: {}", userID);
        return borrowService.findByUserId(userID);
    }

    // Request a book to borrow
    @PostMapping("/borrow")
    public Borrow requestBook(@RequestBody Borrow borrow) {
        logger.info("Requesting book to borrow: {}", borrow);
        return borrowService.requestBook(borrow);
    }

    // Accept a borrow request
    @PutMapping("/borrow/accept")
    public Borrow acceptRequest(@RequestBody Borrow borrow) {
        logger.info("Accepting borrow request: {}", borrow);
        return borrowService.acceptRequest(borrow);
    }

    // Reject a borrow request
    @PutMapping("/borrow/reject")
    public Borrow rejectRequest(@RequestBody Borrow borrow) {
        logger.info("Rejecting borrow request: {}", borrow);
        return borrowService.rejectRequest(borrow);
    }

    // Return a borrowed book
    @PutMapping("/borrow/return")
    public Borrow returnBook(@RequestBody Borrow borrow) {
        logger.info("Returning borrowed book: {}", borrow);
        return borrowService.returnBook(borrow);
    }

    // Get borrow history for a specific book by book ID
    @GetMapping("/borrow/book/{id}")
    public List<Borrow> bookBorrowHistory(@PathVariable long id) {
        logger.info("Fetching borrow history for book ID: {}", id);
        return borrowRepository.findByBookId(id);
    }
}