package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cts.model.Book;
import com.cts.services.BookService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api")
public class BookController {
    @Autowired
    private BookService bookService;

    private static final Logger logger = LoggerFactory.getLogger(BookController.class);

    
    // Get a list of all books.
    @GetMapping("/books")
    public List<Book> getAllBooks(){
        logger.info("Fetching all books");
        return bookService.getAllBooks();  // @return a list of all books
    }

    
      //Get a book by ID.
    @GetMapping("/books/{id}")
    public Book getBookByID(@PathVariable long id){
        logger.info("Fetching book with ID: {}", id);
        return bookService.getBookById(id); // return the book with the specified ID
    }

    //Add a new book
    @PostMapping("/books")
    public @ResponseBody Book addBook(@RequestBody Book book) {
        logger.info("Adding new book: {}", book.getBookTitle());
        return bookService.addBook(book); //return the added book
    }

    
      //Update a book by ID
    @PutMapping("/books/{id}")
    public void updateBook(@RequestBody Book book, @PathVariable long id) {
        logger.info("Updating book with ID: {}", id);
        Book setBook = bookService.getBookById(id);
        setBook.setBookTitle(book.getBookTitle());
        setBook.setAuthor(book.getAuthor());
        setBook.setCategory(book.getCategory());
        setBook.setDescription(book.getDescription());
        setBook.setQuantity(book.getQuantity());
        setBook.setAvailability(book.getAvailability());
        setBook.setPublishedDate(book.getPublishedDate());
        bookService.updateBook(setBook);      //the book details to be updated
        logger.info("Updated book: {}", setBook.getBookTitle());
    }

    //Delete a book by ID.
    @DeleteMapping("/books/{id}")
    public void deleteBook(@PathVariable long id) {
        logger.info("Deleting book with ID: {}", id);
        bookService.deleteBook(id); //Id of the book be deleted
    }
}