package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cts.model.BookRequest;
import com.cts.services.BookRequestService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api")
public class BookRequestController {
    @Autowired
    BookRequestService bookRequestService;

    private static final Logger logger = LoggerFactory.getLogger(BookRequestController.class);

    // Get all book requests
    @GetMapping("/requests")
    public List<BookRequest> getAllRequests(){
        logger.info("Fetching all book requests");
        return bookRequestService.getAllRequests();
    }

    // Get a book request by ID
    @GetMapping("/requests/{id}")
    public BookRequest requestById(@PathVariable long id){
        logger.info("Fetching book request with ID: {}", id);
        return bookRequestService.requestById(id);
    }

    // Add a new book request
    @PostMapping("/requests")
    public BookRequest addRequests(@RequestBody BookRequest br){
        logger.info("Adding new book request: {}", br.toString());
        return bookRequestService.addRequest(br);
    }

    // Update a book request by ID
    @PutMapping("/requests/{id}")
    public BookRequest updateRequest(@RequestBody BookRequest br, @PathVariable long id, @RequestParam("admin") long adminId){
        logger.info("Updating book request with ID: {} by admin ID: {}", id, adminId);
        BookRequest bookRequest = requestById(id);
        return bookRequestService.updateRequest(bookRequest, adminId);
    }

    // Update a book request return by ID
    @PutMapping("/requests_return/{id}")
    public BookRequest updateRequestReturn(@RequestBody BookRequest br, @PathVariable long id){
        logger.info("Updating return for book request with ID: {}", id);
        BookRequest bookRequest = requestById(id);
        return bookRequestService.updateRequestReturn(bookRequest);
    }

    // Delete a book request by ID
    @DeleteMapping("/requests/{id}")
    public void deleteRequest(@PathVariable long id){
        logger.info("Deleting book request with ID: {}", id);
        bookRequestService.deleteRequest(id);
    }
}