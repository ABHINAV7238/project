package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.cts.exception.PasswordNotMatchedException;
import com.cts.exception.PhoneNumberAlreadyExistException;
import com.cts.exception.UserAlreadyExistException;
import com.cts.exception.UserNotFoundException;
import com.cts.model.LoginRequest;
import com.cts.model.User;
import com.cts.services.CustomUserDetails;
import com.cts.services.UserService;

import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api")
public class UserController {
    
    @Autowired
    private UserService userService;

    @Autowired
    private AuthenticationManager authenticationManager;

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    // Welcome message
    @GetMapping("/")
    public String welcome(){
        logger.info("Accessed welcome endpoint");
        return "This is Java Backend ;";
    }

    // Get all users
    @GetMapping("/users")
    public List<User> getAllUsers() {
        logger.info("Fetching all users");
        return userService.getAllUsers();
    }

    // Get a user by ID
    @GetMapping("/users/{id}")
    public User getUserByID(@PathVariable long id) {
        logger.info("Fetching user with ID: {}", id);
        return userService.getUserByID(id);
    }

    // Register a new user
    @PostMapping("/register")
    public User addUser(@RequestBody User user) {
        logger.info("Registering new user with email: {}", user.getEmail());
        User getUser = userService.getUserByEmail(user.getEmail());
        if (getUser == null) {
            if (userService.getUserByPhoneNumber(user.getPhoneNumber()) != null) {
                logger.warn("Phone number already exists: {}", user.getPhoneNumber());
                throw new PhoneNumberAlreadyExistException();
            } else {
                return userService.addUser(user);
            }
        } else {
            logger.warn("User already exists with email: {}", user.getEmail());
            throw new UserAlreadyExistException();
        }
    }

    // Update a user by ID
    @PutMapping("/users/{id}")
    public User updateUser(@RequestBody User user, @PathVariable long id) {
        logger.info("Updating user with ID: {}", id);
        User getUser = userService.getUserByID(id);

        getUser.setName(user.getName());
        getUser.setEmail(user.getEmail());
        getUser.setPhoneNumber(user.getPhoneNumber());
        getUser.setPassword(user.getPassword());
        getUser.setNumBookBorrowed(user.getNumBookBorrowed());
        return userService.updateUser(getUser);
    }

    // Delete a user by ID
    @DeleteMapping("/users/{id}")
    public void deleteUser(@PathVariable long id) {
        logger.info("Deleting user with ID: {}", id);
        User user = userService.getUserByID(id);
        if (user.getId() == id) {
            userService.deleteUser(id);
        } else {
            logger.warn("User not found with ID: {}", id);
            throw new UserNotFoundException(id);
        }
    }

//    // Reset password for a user by ID
//    @PutMapping("/user/reset-password")
//    public void resetPassword(@RequestBody User user, @RequestParam("id") long id){
//        logger.info("Resetting password for user with ID: {}", id);
//        User getUser = userService.getUserByID(id);
//        getUser.setPassword(user.getPassword());
//        userService.updateUser(getUser);
//    }

    // User login
    @PostMapping("/login")
    public @ResponseBody User login(@RequestBody LoginRequest loginRequest, HttpSession session) {
        logger.info("User login attempt with email: {}", loginRequest.getEmail());
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword())
            );
            SecurityContextHolder.getContext().setAuthentication(authentication);
            CustomUserDetails customUserDetails = (CustomUserDetails) authentication.getPrincipal();
            User user = customUserDetails.getUser();
            session.setAttribute("userId", user.getId()); // Store the user ID in the session
            logger.info("User login successful for email: {}", loginRequest.getEmail());
            return user;
        } catch (AuthenticationException e) {
            logger.warn("User login failed for email: {}", loginRequest.getEmail());
            throw new PasswordNotMatchedException();
        }
    }
}