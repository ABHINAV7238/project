package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookNestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookNestApplication.class, args);
		System.out.println("Welcome to Library Management System..");
	}

}
