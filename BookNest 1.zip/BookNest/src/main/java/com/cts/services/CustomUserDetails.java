package com.cts.services;

import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import com.cts.model.User;
import java.util.Collections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomUserDetails implements UserDetails {
	
	private User user;
	
	private static final Logger logger = LoggerFactory.getLogger(CustomUserDetails.class);

	public CustomUserDetails(User user) {
	   this.user = user;
	   logger.info("CustomUserDetails created for user: {}", user.getEmail());
	}

	// Get authorities (roles) for the user
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
	     logger.info("Fetching authorities for user: {}", user.getEmail());
	     return Collections.emptyList();
	}
	
	// Get the User object
	public User getUser() {
		logger.info("Getting user: {}", user.getEmail());
		return user;
	}

	// Set the User object
	public void setUser(User user) {
		logger.info("Setting user: {}", user.getEmail());
		this.user = user;
	}

	// Get the password of the user
	@Override
	public String getPassword() {
		logger.info("Getting password for user: {}", user.getEmail());
		return user.getPassword();
	}

	// Get the username (email) of the user
	@Override
	public String getUsername() {
		logger.info("Getting username for user: {}", user.getEmail());
		return user.getEmail();
	}

	// Check if the account is non-expired
	@Override
	public boolean isAccountNonExpired() {
		logger.info("Checking if account is non-expired for user: {}", user.getEmail());
		return true;
	}

	// Check if the account is non-locked
	@Override
	public boolean isAccountNonLocked() {
		logger.info("Checking if account is non-locked for user: {}", user.getEmail());
		return true;
	}

	// Check if the credentials are non-expired
	@Override
	public boolean isCredentialsNonExpired() {
		logger.info("Checking if credentials are non-expired for user: {}", user.getEmail());
		return true;
	}

	// Check if the account is enabled
	@Override
	public boolean isEnabled() {
		logger.info("Checking if account is enabled for user: {}", user.getEmail());
		return true;
	}
}