package com.cts.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.exception.BookOutOFStockException;
import com.cts.exception.BorrowNotFoundException;
import com.cts.exception.MaximumBooksBorrowedException;
import com.cts.model.Book;
import com.cts.model.Borrow;
import com.cts.model.BorrowStatus;
import com.cts.model.User;
import com.cts.repository.BorrowRepository;

import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class BorrowService {
    @Autowired
    private BorrowRepository borrowRepository;

    @Autowired
    private BookService bookService;

    @Autowired
    private UserService userService;

    private static final Logger logger = LoggerFactory.getLogger(BorrowService.class);

    // Get all borrow records
    public List<Borrow> findAll(){
        logger.info("Fetching all borrow records");
        List<Borrow> borrows = new ArrayList<>();
        borrowRepository.findAll().forEach(borrows::add);
        return borrows;
    }

    // Get a borrow record by ID
    public Borrow findById(long id) {
        logger.info("Fetching borrow record with ID: {}", id);
        return borrowRepository.findById(id).orElseThrow(() -> new BorrowNotFoundException(id));
    }

    // Get all borrow records for a specific user by user ID
    public List<Borrow> findByUserId(Long userID){
        logger.info("Fetching borrow records for user ID: {}", userID);
        return borrowRepository.findByUserId(userID);
    }

    // Delete a borrow request by ID
    public void deleteRequest(long id){
        logger.info("Deleting borrow request with ID: {}", id);
        borrowRepository.deleteById(id);
    }

    // Get pending borrow requests for a specific user by user ID
    public List<Borrow> getPendingBorrowRequestsByUserId(Long userId) {
        logger.info("Fetching pending borrow requests for user ID: {}", userId);
        List<BorrowStatus> statuses = Arrays.asList(BorrowStatus.PENDING, BorrowStatus.ACCEPTED);
        return borrowRepository.findByUserIdAndStatusIn(userId, statuses);
    }

    // Request a book to borrow
    @Transactional
    public Borrow requestBook(Borrow borrowBody) {
        logger.info("Requesting book to borrow: {}", borrowBody);
        User user = userService.getUserByID(borrowBody.getUser().getId());
        Book book = bookService.getBookById(borrowBody.getBook().getId());

        // Check if the user has any pending borrow requests
        List<Borrow> pendingRequests = getPendingBorrowRequestsByUserId(borrowBody.getUser().getId());
        if (pendingRequests.size() >= 5) {
            logger.warn("User has reached the maximum limit of pending borrow requests: {}", user.getId());
            throw new MaximumBooksBorrowedException("You have reached the maximum limit of pending borrow requests.");
        }

        if (book.getAvailability() < 1) {
            logger.warn("Book out of stock: {}", book.getBookTitle());
            throw new BookOutOFStockException(book.getBookTitle());
        }

        LocalDate currentDate = LocalDate.now();
        LocalDate dueDate = currentDate.plusDays(7);

        Borrow borrow = new Borrow(user, book, currentDate, dueDate, BorrowStatus.PENDING);

        logger.info("{} has requested one copy of \"{}\"!", user.getName(), book.getBookTitle());

        return borrowRepository.save(borrow);
    }

    // Accept a borrow request
    public Borrow acceptRequest(Borrow borrow) {
        logger.info("Accepting borrow request: {}", borrow);
        Borrow request = findById(borrow.getBorrowId());

        // Check if the book is available
        Book book = bookService.getBookById(request.getBook().getId());
        if (book.getAvailability() < 1) {
            logger.warn("Book out of stock: {}", book.getBookTitle());
            throw new BookOutOFStockException(book.getBookTitle());
        }

        // Update the borrow request status to accepted
        request.setStatus(BorrowStatus.ACCEPTED);
        borrowRepository.save(request);

        // Decrease the count of available books
        book.borrowBook();
        bookService.updateBook(book);

        // Increment the number of books borrowed by the user
        User user = request.getUser();
        user.userBookBorrow(); // increment
        userService.updateUser(user);

        return request;
    }

    // Reject a borrow request
    public Borrow rejectRequest(Borrow borrow) {
        logger.info("Rejecting borrow request: {}", borrow);
        Borrow request = findById(borrow.getBorrowId());

        // Update the borrow request status to REJECTED
        request.setStatus(BorrowStatus.REJECTED);
        return borrowRepository.save(request);
    }

    // Return a borrowed book
    public Borrow returnBook(Borrow borrow){
        logger.info("Returning borrowed book: {}", borrow);
        Borrow borrowBook = findById(borrow.getBorrowId());
        Book book = bookService.getBookById(borrowBook.getBook().getId());

        // Increment number of books
        book.returnBook();
        bookService.updateBook(book);

        LocalDate currentDate = LocalDate.now();
        borrowBook.setReturnDate(currentDate);

        User user = userService.getUserByID(borrowBook.getUser().getId());
        user.userReturnBook(); // decrement number of books borrowed
        userService.updateUser(user);

        // Update the borrow request status to RETURNED
        borrowBook.setStatus(BorrowStatus.RETURNED);
        return borrowRepository.save(borrowBook);
    }
}