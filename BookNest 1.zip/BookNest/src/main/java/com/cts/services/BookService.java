package com.cts.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.exception.BookNotFoundException;
import com.cts.model.Book;
import com.cts.repository.BookRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;

    private static final Logger logger = LoggerFactory.getLogger(BookService.class);

    // Get all books
    public List<Book> getAllBooks(){
        logger.info("Fetching all books");
        List<Book> book = new ArrayList<>();
        bookRepository.findAll().forEach(book::add);
        return book;
    }

    // Get a book by ID
    public Book getBookById(long id) {
        logger.info("Fetching book with ID: {}", id);
        return bookRepository.findById(id).orElseThrow(() -> new BookNotFoundException(id));
    }

    // Add a new book
    public Book addBook(Book book) {
        logger.info("Adding new book: {}", book.getBookTitle());
        return bookRepository.save(book);
    }

    // Update an existing book
    public void updateBook(Book book){
        logger.info("Updating book with ID: {}", book.getId());
        bookRepository.save(book);
    }

    // Delete a book by ID
    public void deleteBook(long id){
        logger.info("Deleting book with ID: {}", id);
        bookRepository.deleteById(id);
    }
}