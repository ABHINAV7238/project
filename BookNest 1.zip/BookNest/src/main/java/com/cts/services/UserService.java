package com.cts.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.exception.UserNotFoundException;
import com.cts.model.User;
import com.cts.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class UserService {
	
	@Autowired
	private PasswordEncoder encoder;
    @Autowired
    private UserRepository userRepository;

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    // Get all users
    public List<User> getAllUsers(){
        logger.info("Fetching all users");
        List<User> users = new ArrayList<>();
        userRepository.findAll().forEach(users::add);
        return users;
    }

    // Get a user by ID
    public User getUserByID(long id) {
        logger.info("Fetching user with ID: {}", id);
        return userRepository.findById(id).orElseThrow(() -> new UserNotFoundException(id));
    }

    // Get a user by email
    public User getUserByEmail(String email){
        logger.info("Fetching user with email: {}", email);
        return userRepository.findByEmail(email);
    }

    // Get a user by phone number
    public User getUserByPhoneNumber(long number){
        logger.info("Fetching user with phone number: {}", number);
        return userRepository.findByPhoneNumber(number);
    }

    // Add a new user
    public User addUser(User users) {
        logger.info("Adding new user with email: {}", users.getEmail());
        users.setPassword(encoder.encode(users.getPassword()));
        return userRepository.save(users);
    }

    // Update an existing user
    public User updateUser(User user){
        logger.info("Updating user with ID: {}", user.getId());
        user.setPassword(encoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    // Delete a user by ID
    public void deleteUser(long id){
        logger.info("Deleting user with ID: {}", id);
        userRepository.deleteById(id);
    }
}