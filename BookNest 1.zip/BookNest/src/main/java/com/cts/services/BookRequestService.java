package com.cts.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Admin;
import com.cts.model.BookRequest;
import com.cts.model.BorrowStatus;
import com.cts.repository.BookRequestRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class BookRequestService {
    
    @Autowired
    BookRequestRepository bookRequestRepository;

    private static final Logger logger = LoggerFactory.getLogger(BookRequestService.class);

    // Get all book requests
    public List<BookRequest> getAllRequests(){
        logger.info("Fetching all book requests");
        List<BookRequest> br = new ArrayList<>();
        bookRequestRepository.findAll().forEach(br::add);
        return br;
    }

    // Add a new book request
    public BookRequest addRequest(BookRequest br){
        logger.info("Adding new book request: {}", br);
        br.setStatus(BorrowStatus.REQUESTED);
        return bookRequestRepository.save(br);
    }

    // Get a book request by ID
    public BookRequest requestById(long id){
        logger.info("Fetching book request with ID: {}", id);
        return bookRequestRepository.findById(id).orElseThrow();
    }

    // Update a book request by ID
    public BookRequest updateRequest(BookRequest br, long adminId){
        logger.info("Updating book request with ID: {} by admin ID: {}", br.getId(), adminId);
        // get existing book request
        BookRequest existingRequest = requestById(br.getId());

        // set book returned status
        existingRequest.setStatus(BorrowStatus.RETURNED);
        existingRequest.setBook(br.getBook());
        existingRequest.setUser(br.getUser());

        Admin admin = new Admin();
        admin.setId(adminId);
//        existingRequest.setAdmin(admin);
        // save edited data
        bookRequestRepository.save(existingRequest);

        return existingRequest;
    }

    // Update a book request return by ID
    public BookRequest updateRequestReturn(BookRequest br){
        logger.info("Updating return for book request with ID: {}", br.getId());
        // get existing book request
        BookRequest existingRequest = requestById(br.getId());

        // set book returned status
        existingRequest.setStatus(BorrowStatus.RETURNED);
        existingRequest.setBook(br.getBook());
        existingRequest.setUser(br.getUser());
        // existingRequest.setAdmin(br.getAdmin());
        // save edited data
        bookRequestRepository.save(existingRequest);

        return existingRequest;
    }

    // Delete a book request by ID
    public void deleteRequest(long id){
        logger.info("Deleting book request with ID: {}", id);
        bookRequestRepository.deleteById(id);
    }
}