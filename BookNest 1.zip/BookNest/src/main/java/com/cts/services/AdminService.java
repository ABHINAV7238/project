package com.cts.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.exception.PasswordNotMatchedException;
import com.cts.exception.UserAlreadyExistException;
import com.cts.exception.UserNotFoundException;
import com.cts.model.Admin;
import com.cts.model.LoginRequest;
import com.cts.repository.AdminRepository;
import com.cts.repository.BorrowRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class AdminService {
    @Autowired
    private AdminRepository adminRepository;

    private BorrowRepository borrowRepository;
    
//	@Autowired
//	private PasswordEncoder encoder;

    private static final Logger logger = LoggerFactory.getLogger(AdminService.class);

    // Get all admins
    public List<Admin> getAllAdmin() {
        logger.info("Fetching all admins");
        List<Admin> admin = new ArrayList<>();
        adminRepository.findAll().forEach(admin::add);
        return admin;
    }

    // Find admin by ID
    public Admin findById(long id){
        logger.info("Fetching admin with ID: {}", id);
        return adminRepository.findById(id).orElseThrow(() -> new UserNotFoundException(id));
    }

    // Add a new admin
    public Admin addAdmin(Admin admin) {
        logger.info("Adding new admin with email: {}", admin.getEmail());
        Admin getAdmin = adminRepository.findByEmail(admin.getEmail());
        if (getAdmin == null) {
//        	 admin.setPassword(encoder.encode(admin.getPassword()));
            return adminRepository.save(admin);
        } else {
            logger.warn("Admin already exists with email: {}", admin.getEmail());
            throw new UserAlreadyExistException();
        }
    }

    // Delete admin by ID
    public void deleteAdmin(long id) {
        logger.info("Deleting admin with ID: {}", id);
        if (adminRepository.existsById(id)) {
            adminRepository.deleteById(id);
        } else {
            logger.warn("Admin not found with ID: {}", id);
            throw new UserNotFoundException(id);
        }
    }

    // Update admin details
    public Admin updateAdmin(Admin admin){
        logger.info("Updating admin with email: {}", admin.getEmail());
        return adminRepository.save(admin);
    }

    // Admin login
    public Admin login(LoginRequest loginRequest){
    	
        logger.info("Admin login attempt with email: {}", loginRequest.getEmail());
        Admin admin = adminRepository.findByEmail(loginRequest.getEmail());
        System.out.println(loginRequest.getEmail() + " " + loginRequest.getPassword());
        if (admin != null && admin.getPassword().equals(loginRequest.getPassword())) {
            logger.info("Admin login successful for email: {}", loginRequest.getEmail());
            return admin;
        } else {
            logger.info("Admin login failed for email: {}", loginRequest.getEmail());
            throw new PasswordNotMatchedException();
        }
    }
}