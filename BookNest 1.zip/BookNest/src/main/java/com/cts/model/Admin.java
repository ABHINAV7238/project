package com.cts.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="Admin")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Admin {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
	
    private String name;
    
    @Column(name = "email", nullable = false, unique = true)
    private String email;
    
    @Column(name = "phone_number", nullable = false, unique = true)
    private long phoneNumber;
    
    private String password;

}


