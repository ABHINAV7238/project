package com.cts.model;

public enum BorrowStatus {
    PENDING,
    ACCEPTED,
    RETURNED,
    REJECTED,
    REQUESTED

}
