package com.cts.model;


import jakarta.persistence.*;
import lombok.*;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="book_request")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "book_id")

    private Book book;

    @ManyToOne
    @JoinColumn(name = "user_id")

    private User user;
    
//    @ManyToOne(optional = true)
//    @JoinColumn(name = "admin_id", nullable = true)
//    private Admin admin;
//    
    private BorrowStatus status;

}
