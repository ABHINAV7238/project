package com.cts.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Books")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "book_title", nullable = false)
    private String bookTitle;

    @Column(nullable = false)
    private String author;

    @Column(nullable = false)
    private String category;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    @Min(value = 0)
    private long quantity;

    @Column(nullable = false)
    @Min(value = 0)
    private long availability;

    @Column(name = "published_date", nullable = false)
    String publishedDate;

    @Column(name = "registered_date", nullable = false)
    String registeredDate = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));

    @OneToMany(mappedBy = "book")
    private List<Borrow> borrows;

    public List<Borrow> getBorrows() {
        return borrows;
    }

    public void setBorrows(List<Borrow> borrows) {
        this.borrows = borrows;
    }

    // Ensure quantity and availability are synchronized when setting quantity
    public void setQuantity(long quantity) {
        this.quantity = quantity;
        this.availability = quantity;
    }

    public long getAvailability() {
        return availability;
    }

    public void setAvailability(long availability) {
        if (availability >= this.quantity) {
            this.availability = this.quantity;
        } else {
            this.availability = availability;
        }
    }

    public void borrowBook() {
        if (this.availability > 0) {
            System.out.println("Borrowing book: " + this.bookTitle);
            this.availability--;
        }
    }

    public void returnBook() {
        if (this.availability < this.quantity) {
            System.out.println("Returning book: " + this.bookTitle);
            this.availability++;
        }
    }
}