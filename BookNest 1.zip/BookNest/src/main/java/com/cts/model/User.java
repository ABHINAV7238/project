package com.cts.model;

import java.time.LocalDate;

import java.util.List;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Users1")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    
    @Column(name = "name", nullable = false)
    private String name;
    
    @Column(name = "email", nullable = false, unique = true)
    private String email;
    
    @Column(name = "phone_number", nullable = false, unique = true)
    private long phoneNumber;
    
    @Column(name = "password", nullable = false)
    private String password;
    
    @Column(name = "registered_date")
    private LocalDate registeredDate ;
    
    @Column(name = "numBookBorrowed")
    @Min(value = 0)
    private int numBookBorrowed;

    // In User class
    @OneToMany(mappedBy = "user")
    private List<Borrow> borrows;

    public void userBookBorrow(){
        this.numBookBorrowed++;
    }

    public void userReturnBook(){
        this.numBookBorrowed--;
    }

	
 
	
}
