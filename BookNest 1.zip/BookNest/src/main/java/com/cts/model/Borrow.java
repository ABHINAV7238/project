package com.cts.model;

import java.time.LocalDate;


import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "Borrow")

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Borrow {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long borrowId;

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonIgnoreProperties("borrows")
    private User user;

    @ManyToOne
    @JoinColumn(name = "book_id")
    @JsonIgnoreProperties("borrows")
    private Book book;
     
    @Enumerated(EnumType.STRING)
    private BorrowStatus status;


    private LocalDate borrowDate;

    private LocalDate returnDate;

    private LocalDate dueDate;
    
    public Borrow(User user, Book book, LocalDate borrowDate, LocalDate dueDate, BorrowStatus status) {
        this.user = user;
        this.book = book;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.status = status;
    }
}


